
document.querySelector('form').addEventListener('submit', function (e) {
    const phone = document.querySelector('input[name="number"]');
    if (phone && !/^\d{10}$/.test(phone.value)) {
        alert("Phone number must be 10 digits.");
        phone.focus();
        e.preventDefault();
    }

    const cgpa = document.querySelector('input[name="cgpa"]');
    if (cgpa && (cgpa.value < 0 || cgpa.value > 10)) {
        alert("CGPA must be between 0 and 10.");
        cgpa.focus();
        e.preventDefault();
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const form = document.querySelector('form');
    if (!form) return;

    form.addEventListener('submit', function (e) {
        let isValid = true;

        // Full Name - not empty
        const name = form.querySelector('input[name="name"]');
        if (name && name.value.trim() === "") {
            alert("Full Name is required.");
            name.focus();
            isValid = false;
        }

        // Student ID - must be alphanumeric
        const studentId = form.querySelector('input[name="student_id"]');
        if (studentId && !/^[a-zA-Z0-9]+$/.test(studentId.value)) {
            alert("Student ID must be alphanumeric.");
            studentId.focus();
            isValid = false;
        }

        // Email - basic pattern
        const email = form.querySelector('input[name="email"]');
        if (email && !/^\S+@\S+\.\S+$/.test(email.value)) {
            alert("Enter a valid email address.");
            email.focus();
            isValid = false;
        }

        // Phone Number - must be 10 digits
        const number = form.querySelector('input[name="number"]');
        if (number && !/^\d{10}$/.test(number.value)) {
            alert("Phone number must be 10 digits.");
            number.focus();
            isValid = false;
        }

        // Address - not empty
        const address = form.querySelector('textarea[name="address"]');
        if (address && address.value.trim() === "") {
            alert("Address is required.");
            address.focus();
            isValid = false;
        }

        // Gender - must be selected
        const gender = form.querySelector('select[name="gender"]');
        if (gender && gender.value === "") {
            alert("Please select a gender.");
            gender.focus();
            isValid = false;
        }

        // Date of Birth - must be selected
        const dob = form.querySelector('input[name="dob"]');
        if (dob && dob.value === "") {
            alert("Date of Birth is required.");
            dob.focus();
            isValid = false;
        }

        // Accommodation Type - one must be selected
        const accomodation = form.querySelectorAll('input[name="accomodation"]');
        if (accomodation.length > 0 && !Array.from(accomodation).some(r => r.checked)) {
            alert("Please select an accommodation type.");
            isValid = false;
        }

        // Academic Details - only if present in form
        const course = form.querySelector('input[name="cname"]');
        if (course && course.value.trim() === "") {
            alert("Course Name is required.");
            course.focus();
            isValid = false;
        }

        const fyear = form.querySelector('select[name="fyear"]');
        const tyear = form.querySelector('select[name="tyear"]');
        if (fyear && fyear.value === "") {
            alert("Please select a start year.");
            fyear.focus();
            isValid = false;
        }
        if (tyear && tyear.value === "") {
            alert("Please select an end year.");
            tyear.focus();
            isValid = false;
        }

        const dname = form.querySelector('input[name="dname"]');
        if (dname && dname.value.trim() === "") {
            alert("Department Name is required.");
            dname.focus();
            isValid = false;
        }

        const coname = form.querySelector('input[name="coname"]');
        if (coname && coname.value.trim() === "") {
            alert("College Name is required.");
            coname.focus();
            isValid = false;
        }

        const uname = form.querySelector('input[name="uname"]');
        if (uname && uname.value.trim() === "") {
            alert("University Name is required.");
            uname.focus();
            isValid = false;
        }

        const cgpa = form.querySelector('input[name="cgpa"]');
        if (cgpa && (cgpa.value < 0 || cgpa.value > 10)) {
            alert("CGPA must be between 0 and 10.");
            cgpa.focus();
            isValid = false;
        }

        const checkbox = form.querySelector('input[type="checkbox"]');
        if (checkbox && !checkbox.checked) {
            alert("You must declare that the information is correct.");
            checkbox.focus();
            isValid = false;
        }

        if (!isValid) {
            e.preventDefault(); // stop form submission
        }
    });
});

