from django.contrib import admin
from.models import details
from.models import adetails

# Register your models here.
admin.site.register(details)
admin.site.register(adetails)
