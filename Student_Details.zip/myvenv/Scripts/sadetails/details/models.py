from django.db import models

# Create your models here.
# class details(models.Model):
#     name=models.CharField(max_length=50,default="")
#     id=models.CharField(max_length=50,default="")
#     email=models.CharField(max_length=50,default="")
#     number=models.IntegerField(max_length=50,default="")
#     address=models.CharField(max_length=200,default="")

from django.db import models

# Create your models here.
class details(models.Model):
    GENDER_CHOICES = [
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Others', 'Others'),
    ]

    ACCOMMODATION_CHOICES = [
        ('Hostel', 'Hostel'),
        ('Day Scholar', 'Day Scholar'),
    ]

    name = models.CharField(max_length=50, default="")
    student_id = models.CharField(max_length=50, default="")
    email = models.CharField(max_length=50, default="")
    number = models.BigIntegerField(default=10)
    address = models.CharField(max_length=200, default="")
    gender = models.CharField(max_length=10, choices=GENDER_CHOICES, default="")
    dob = models.DateField(null=True, blank=True)
    accommodation = models.CharField(max_length=20, choices=ACCOMMODATION_CHOICES, default="")

    def __str__(self):
        return self.name

# student Academic Details

from django.db import models

class adetails(models.Model):
    
    YEAR_CHOICES=[(str(fyear), str(fyear)) for fyear in range(2000, 2026)]
    
    cname=models.CharField(max_length=50,default='')

    f_year = models.CharField(max_length=4, choices=YEAR_CHOICES, default="")
    t_year = models.CharField(max_length=4, choices=YEAR_CHOICES, default="")

    
    dname=models.CharField(max_length=100,default='')
    coname=models.CharField(max_length=100,default='')
    uname=models.CharField(max_length=100,default='')
    cgpa=models.FloatField(max_length=10,default='')
    
    def __str__(self):
        return self.cname












