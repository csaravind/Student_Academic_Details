from django.shortcuts import render, redirect
from django.http import HttpResponse
from.models import details

# Create your views here.
# def sd(request):
#     if request.method=="post":
#         name=request.POST['name']
#         student_id=request.POST['student_id']
#         email=request.POST['email']
#         number=request.POST['number']
#         address=request.POST['address']
#         gender=request.POST['gender']
#         dob=request.POST['dob']
#         accomodation=request.POST['accomodation']

#         obj=details()
#         obj.Name=name
#         obj.Student_Id=student_id
#         obj.Email=email
#         obj.Number=number
#         obj.Address=address
#         obj.Gender=gender
#         obj.Dob=dob
#         obj.Accomodation=accomodation
#         obj.save()

#         return render(request,"st.html")
    
#     return render(request,"st.html")



from django.shortcuts import render
from .models import details
from .models import adetails

def sd(request):
    if request.method == "POST":
        name = request.POST['name']
        student_id = request.POST['student_id']
        email = request.POST['email']
        number = request.POST['number']
        address = request.POST['address']
        gender = request.POST['gender']
        dob = request.POST['dob']
        accommodation = request.POST['accomodation']

        obj = details()
        obj.name = name                      
        obj.student_id = student_id         
        obj.email = email
        obj.number = number
        obj.address = address
        obj.gender = gender
        obj.dob = dob
        obj.accommodation = accommodation
        obj.save()

        return redirect('sad')

        # return render(request, "st.html")

    return render(request, "st.html")


# Student Acadamic Details
# def sad(request):
#     if request.method=="POST":

#         fyear = request.POST.get('fyear')  # get start year from form
#         tyear = request.POST.get('tyear')


#         cname=request.POST['cname']
#         # fyear=request.POST['fyear']
#         # tyear=request.POST['tyear']
#         dname=request.POST['dname']
#         coname=request.POST['coname']
#         uname=request.POST['uname']
#         cgpa=request.POST['cgpa']

#         obj1=adetails()
#         f_year=fyear
#         t_year=tyear
#         obj1.cname=cname
#         # obj1.fyear=fyear
#         # obj1.tyear=tyear
#         obj1.dname=dname
#         obj1.coname=coname
#         obj1.uname=uname
#         obj1.cgpa=cgpa
#         obj1.save()

#         return render(request, "sad.html")

#     return render(request, "sad.html")

def sad_view(request):
    if request.method == "POST":
        fyear = request.POST.get('fyear')  
        tyear = request.POST.get('tyear')  

        cname = request.POST['cname']
        dname = request.POST['dname']
        coname = request.POST['coname']
        uname = request.POST['uname']
        cgpa = request.POST['cgpa']

        obj1 = adetails()
        obj1.cname = cname
        obj1.f_year = fyear  
        obj1.t_year = tyear  
        obj1.dname = dname
        obj1.coname = coname
        obj1.uname = uname
        obj1.cgpa = cgpa
        obj1.save()
        return render(request, "sad.html")
    return render(request, "sad.html")














# validation code
import re
from django.core.validators import validate_email
from django.core.exceptions import ValidationError

def sd(request):
    if request.method == "POST":
        try:
            name = request.POST['name']
            student_id = request.POST['student_id']
            email = request.POST['email']
            number = request.POST['number']
            address = request.POST['address']
            gender = request.POST['gender']
            dob = request.POST['dob']
            accommodation = request.POST['accomodation']

            # Basic Validation
            if not re.match(r"^\d{10}$", number):
                return HttpResponse("Invalid phone number")

            try:
                validate_email(email)
            except ValidationError:
                return HttpResponse("Invalid email address")

            obj = details(
                name=name,
                student_id=student_id,
                email=email,
                number=number,
                address=address,
                gender=gender,
                dob=dob,
                accommodation=accommodation
            )
            obj.save()

            return redirect('sad')

        except Exception as e:
            return HttpResponse(f"Error: {str(e)}")

    return render(request, "st.html")


def sad_view(request):
    if request.method == "POST":
        try:
            fyear = request.POST.get('fyear')
            tyear = request.POST.get('tyear')
            cname = request.POST['cname']
            dname = request.POST['dname']
            coname = request.POST['coname']
            uname = request.POST['uname']
            cgpa = request.POST['cgpa']

            # Validation
            if not (fyear and tyear and cname and dname and coname and uname and cgpa):
                return HttpResponse("All fields are required.")

            if not (0 <= float(cgpa) <= 10):
                return HttpResponse("CGPA must be between 0 and 10")

            obj1 = adetails(
                cname=cname,
                f_year=fyear,
                t_year=tyear,
                dname=dname,
                coname=coname,
                uname=uname,
                cgpa=cgpa
            )
            obj1.save()
            return render(request, "sad.html")
        except Exception as e:
            return HttpResponse(f"Error: {str(e)}")

    return render(request, "sad.html")
 